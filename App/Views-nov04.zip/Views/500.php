{% extends "layout/error.php" %}
{% block title %}Error 500{% endblock %}

{% block body %}
<div class="container">
    <div class="flex-item">
        <h3>500: Internal Server Error :(</h3>
        <p>Sorry, an error occured.</p>
    </div>
</div>
{% endblock %}